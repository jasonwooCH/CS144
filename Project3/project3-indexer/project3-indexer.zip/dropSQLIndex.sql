DROP INDEX sp_index ON ItemPoint;

DROP TABLE IF EXISTS ItemPoint;